BAI TAP: QUAN LY DIEM THI

CSDL: QuanLyDiemThi
Bang: HocSinh, MonHoc, GiaoVien, BangDiem

Khoa chinh:
HocSinh.MaHS
MonHoc.MaMH
GiaoVien.MaGV
BangDiem (MaHS, MaMH)

Khoa ngoai:
BangDiem.MaHS -> HocSinh.MaHS
BangDiem.MaMH -> MonHoc.MaMH
MonHoc.MaGV -> GiaoVien.MaGV

Day la lenh MySQL.
