BAI THUC HANH MYSQL - TAO BANG CLASS VA TEACHER

CSDL su dung: student_management

Cau lenh:
USE student_management;

CREATE TABLE Class (
    id INT,
    name VARCHAR(200)
);

CREATE TABLE Teacher (
    id INT,
    name VARCHAR(200),
    age INT,
    country VARCHAR(50)
);

Kiem tra:
SHOW TABLES;

SELECT * FROM Class;
SELECT * FROM Teacher;

Luu y:
- Neu ten CSDL o bai truoc cua ban khac student_management, thay dong USE student_management; bang ten CSDL cua ban.
- Chay trong MySQL Workbench.
