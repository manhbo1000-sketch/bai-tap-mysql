USE student_management;

CREATE TABLE Class (
    id INT,
    name VARCHAR(200)
);

CREATE TABLE Teacher (
    id INT,
    name VARCHAR(200),
    age INT,
    country VARCHAR(50)
);

SHOW TABLES;

SELECT * FROM Class;
SELECT * FROM Teacher;
